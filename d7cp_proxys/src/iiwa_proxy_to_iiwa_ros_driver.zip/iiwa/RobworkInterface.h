/*
 * RobworkInterface.h
 *
 *  Created on: Jan 24, 2017
 *      Author: josl
 */

#ifndef D7PC_ROS_D7CP_PROXYS_SRC_IIWA_ROBWORKINTERFACE_H_
#define D7PC_ROS_D7CP_PROXYS_SRC_IIWA_ROBWORKINTERFACE_H_

#include <memory>
#include "RosProxy.h"
#include <rw/math/Q.hpp>
#include <rw/math/Transform3D.hpp>

namespace iiwa
{

class RobworkInterface
{

public:
	RobworkInterface(std::shared_ptr<RosProxy> ros_proxy);
	virtual ~RobworkInterface();

	void movePtp(rw::math::Q q);
	void movePtp(std::vector<rw::math::Q> path, double eps=0.1);
	void movePtpBlockExperimental(rw::math::Q q);
	void movePtpBlockTimeout(rw::math::Q q, double timeout_sec);

	rw::math::Q getQ();
	rw::math::Transform3D<> getBaseTtool();

	void moveLin(rw::math::Transform3D<> baseTtool);
	void moveLin(double x, double y, double z, double rx, double ry, double rz);

	void cartesian_compliace(double cx, double cy, double cz, double cRx, double cRy, double cRz);
	void compliace_disable();

	bool is_at(rw::math::Q q, double eps = 0.01);
	bool is_at(rw::math::Transform3D<> baseTtool, double eps = 0.01);

	rw::math::Q toRw(iiwa_msgs::JointPosition msg);
	rw::math::Transform3D<> toRw(geometry_msgs::PoseStamped msg);

	iiwa_msgs::JointPosition toRos(rw::math::Q);
	geometry_msgs::PoseStamped toRos(rw::math::Transform3D<> baseTtool);
	geometry_msgs::PoseStamped toRos(double x, double y, double z, double qx, double qy, double qz, double qw);



private:
	void block_while_moving();
	void block_while_moving(rw::math::Q qInit, rw::math::Q qLast, ros::Time tStart);
	bool is_moving();


private:
	std::shared_ptr<RosProxy> proxy;

};

} /* namespace iiwa */

#endif /* D7PC_ROS_D7CP_PROXYS_SRC_IIWA_ROBWORKINTERFACE_H_ */
