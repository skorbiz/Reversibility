/*
 * RosProxy.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: josl
 */

#include <iiwa/RosProxy.h>

#include <iostream>

namespace iiwa {

RosProxy::RosProxy()
{
	nh_ = ros::NodeHandle();

	publisher_joint_position_  = nh_.advertise<iiwa_msgs::JointPosition>("iiwa/command/JointPosition", 100);
	publisher_cartesian_pose_  = nh_.advertise<geometry_msgs::PoseStamped>("iiwa/command/CartesianPose", 100);
	publisher_configuration_smart_servo_  = nh_.advertise<iiwa_msgs::SmartServoMode>("/iiwa/command/configureSmartServo", 100);

	subscriber_joint_position = nh_.subscribe("iiwa/state/JointPosition", 1, &RosProxy::callback_joint_position, this);
	subscriber_joint_torque_ = nh_.subscribe("iiwa/state/JointTorque", 1, &RosProxy::callback_joint_torque, this);

	subscriber_cartesian_pose_ = nh_.subscribe("iiwa/state/CartesianPose", 1, &RosProxy::callback_cartesian_pose, this);
	subscriber_cartesian_wrench_ = nh_.subscribe("iiwa/state/CartesianWrench", 1, &RosProxy::callback_cartesian_wrench, this);
}

RosProxy::~RosProxy()
{
}

void RosProxy::post_joint_position(const iiwa_msgs::JointPosition & msg)
{
	publisher_joint_position_.publish(msg);
}

void RosProxy::post_cartesian_pose(const geometry_msgs::PoseStamped & msg)
{
	publisher_cartesian_pose_.publish(msg);
}

void RosProxy::post_configuration_smart_servo(const iiwa_msgs::SmartServoMode & msg)
{
	publisher_configuration_smart_servo_.publish(msg);
}

iiwa_msgs::JointPosition RosProxy::get_msg_joint_position()
{
	std::lock_guard<std::mutex> lock(mutex);
	return msg_joint_position;
}

iiwa_msgs::JointTorque RosProxy::get_msg_joint_torque()
{
	std::lock_guard<std::mutex> lock(mutex);
	return msg_joint_torque;
}

geometry_msgs::PoseStamped RosProxy::get_msg_cartesian_pose()
{
	std::lock_guard<std::mutex> lock(mutex);
	return msg_cartesian_pose;
}

geometry_msgs::WrenchStamped RosProxy::get_msg_cartesian_wrehnch()
{
	std::lock_guard<std::mutex> lock(mutex);
	return msg_cartesian_wrehnch;
}

void RosProxy::callback_joint_position(const iiwa_msgs::JointPosition::ConstPtr & msg)
{
	std::lock_guard<std::mutex> lock(mutex);
	msg_joint_position = *msg;
}

void RosProxy::callback_joint_torque(const iiwa_msgs::JointTorque::ConstPtr & msg)
{
	std::lock_guard<std::mutex> lock(mutex);
	msg_joint_torque = *msg;
}

void RosProxy::callback_cartesian_pose(const geometry_msgs::PoseStamped::ConstPtr & msg)
{
	std::lock_guard<std::mutex> lock(mutex);
	msg_cartesian_pose = *msg;
}

void RosProxy::callback_cartesian_wrench(const geometry_msgs::WrenchStamped::ConstPtr & msg)
{
	std::lock_guard<std::mutex> lock(mutex);
	msg_cartesian_wrehnch = *msg;
}



} /* namespace iiwa */

