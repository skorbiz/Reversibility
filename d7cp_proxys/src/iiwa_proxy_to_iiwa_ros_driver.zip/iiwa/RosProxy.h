/*
 * RosProxy.h
 *
 *  Created on: Jan 20, 2017
 *      Author: josl
 */

#ifndef D7PC_ROS_D7CP_PROXYS_INCLUDE_D7CP_PROXYS_IIWA_ROSPROXY_H_
#define D7PC_ROS_D7CP_PROXYS_INCLUDE_D7CP_PROXYS_IIWA_ROSPROXY_H_

#include <ros/ros.h>
#include <mutex>

#include <iiwa_msgs/JointPosition.h>
#include <iiwa_msgs/JointTorque.h>
#include <iiwa_msgs/CartesianQuantity.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/WrenchStamped.h>

#include <iiwa_msgs/ConfigureSmartServo.h>
#include <iiwa_msgs/SmartServoMode.h>


namespace iiwa {

class RosProxy
{

public:
	RosProxy();
	virtual ~RosProxy();

	void post_joint_position(const iiwa_msgs::JointPosition & msg);
	void post_cartesian_pose(const geometry_msgs::PoseStamped & msg);
	void post_configuration_smart_servo(const iiwa_msgs::SmartServoMode & msg);

	 iiwa_msgs::JointPosition get_msg_joint_position();
	 iiwa_msgs::JointTorque get_msg_joint_torque();
	 geometry_msgs::PoseStamped get_msg_cartesian_pose();
	 geometry_msgs::WrenchStamped get_msg_cartesian_wrehnch();


private:
	 void callback_joint_position(const iiwa_msgs::JointPosition::ConstPtr & q_robot);
	 void callback_joint_torque(const iiwa_msgs::JointTorque::ConstPtr & torque_robot);
	 void callback_cartesian_pose(const geometry_msgs::PoseStamped::ConstPtr & c_robot);
	 void callback_cartesian_wrench(const geometry_msgs::WrenchStamped::ConstPtr & wrench_robot);

public:
	 iiwa_msgs::JointPosition msg_joint_position;
	 iiwa_msgs::JointTorque msg_joint_torque;
	 geometry_msgs::PoseStamped msg_cartesian_pose;
	 geometry_msgs::WrenchStamped msg_cartesian_wrehnch;

private:
	 ros::NodeHandle nh_;
	 std::mutex mutex;

	 ros::Publisher publisher_joint_position_;
	 ros::Publisher publisher_cartesian_pose_;
	 ros::Publisher	publisher_configuration_smart_servo_;

	 ros::Subscriber subscriber_joint_position;
	 ros::Subscriber subscriber_joint_torque_;
	 ros::Subscriber subscriber_cartesian_pose_;
	 ros::Subscriber subscriber_cartesian_wrench_;

};
} /* namespace iiwa */
#endif /* D7PC_ROS_D7CP_PROXYS_INCLUDE_D7CP_PROXYS_IIWA_ROSPROXY_H_ */
