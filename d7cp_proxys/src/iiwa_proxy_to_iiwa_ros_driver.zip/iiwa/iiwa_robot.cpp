#include <iiwa/iiwa_robot.h>
#include <iostream>
#include <math.h>

namespace iiwa {

IIWARobot::IIWARobot(RosProxy & rosproxy) :
		proxy(rosproxy)
{
}

IIWARobot::~IIWARobot()
{
}


Qstate IIWARobot::getQ()
{
	iiwaState state;
	auto q_robot = & proxy.msg_joint_position;
	state.qstate.q1 = q_robot->position.a1;
	state.qstate.q2 = q_robot->position.a2;
	state.qstate.q3 = q_robot->position.a3;
	state.qstate.q4 = q_robot->position.a4;
	state.qstate.q5 = q_robot->position.a5;
	state.qstate.q6 = q_robot->position.a6;
	state.qstate.q7 = q_robot->position.a7;
	return state.qstate;
}

iiwaState IIWARobot::getState()
{
	iiwaState state;
	auto c_robot = & proxy.msg_cartesian_pose;
	state.cstate.x = c_robot->pose.position.x;
	state.cstate.y = c_robot->pose.position.y;
	state.cstate.z = c_robot->pose.position.z;
	state.cstate.Rx = c_robot->pose.orientation.x;
	state.cstate.Ry = c_robot->pose.orientation.y;
	state.cstate.Rz = c_robot->pose.orientation.z;
	state.cstate.w = c_robot->pose.orientation.w;
	return state;
}

void IIWARobot::moveQ(const Qstate & state) {
	
	iiwa_msgs::JointPosition iiwa_pose;
	iiwa_pose.position.a1 = state.q1;
	iiwa_pose.position.a2 = state.q2;
	iiwa_pose.position.a3 = state.q3;
	iiwa_pose.position.a4 = state.q4;
	iiwa_pose.position.a5 = state.q5;
	iiwa_pose.position.a6 = state.q6;
	iiwa_pose.position.a7 = state.q7;

	proxy.post_joint_position(iiwa_pose);
}

void IIWARobot::move_dQ(const Qstate & d_state) {
	iiwa_msgs::JointPosition iiwa_pose;
	iiwaState target_state;
	Qstate current_qstate;

	iiwa_pose.position.a1 = d_state.q1 + current_qstate.q1;
	iiwa_pose.position.a2 = d_state.q2 + current_qstate.q2;
	iiwa_pose.position.a3 = d_state.q3 + current_qstate.q3;
	iiwa_pose.position.a4 = d_state.q4 + current_qstate.q4;
	iiwa_pose.position.a5 = d_state.q5 + current_qstate.q5;
	iiwa_pose.position.a6 = d_state.q6 + current_qstate.q6;
	iiwa_pose.position.a7 = d_state.q7 + current_qstate.q7;

	target_state.qstate.q1  = d_state.q1 + current_qstate.q1;
	target_state.qstate.q2  = d_state.q2 + current_qstate.q2;
	target_state.qstate.q3  = d_state.q3 + current_qstate.q3;
	target_state.qstate.q4  = d_state.q4 + current_qstate.q4;
	target_state.qstate.q5  = d_state.q5 + current_qstate.q5;
	target_state.qstate.q6  = d_state.q6 + current_qstate.q6;
	target_state.qstate.q7  = d_state.q7 + current_qstate.q7;
	proxy.post_joint_position(iiwa_pose);
}

void IIWARobot::moveC(const Cstate & state) {
	geometry_msgs::PoseStamped c_pose;
	iiwaState target_state;

	target_state.cstate.x = c_pose.pose.position.x		= state.x;
	target_state.cstate.y = c_pose.pose.position.y		= state.y;
	target_state.cstate.z = c_pose.pose.position.z		= state.z;
	target_state.cstate.Rx = c_pose.pose.orientation.x	= state.Rx;
	target_state.cstate.Ry = c_pose.pose.orientation.y	= state.Ry;
	target_state.cstate.Rz = c_pose.pose.orientation.z	= state.Rz;
	target_state.cstate.w = c_pose.pose.orientation.w   = state.w;
	proxy.post_cartesian_pose(c_pose);
}

void IIWARobot::move_dc(const Cstate & d_state) {
	geometry_msgs::PoseStamped c_pose;
	iiwaState target_state;
	Cstate current_cstate = getState().cstate;

	target_state.cstate.x = c_pose.pose.position.x		= d_state.x + current_cstate.x;
	target_state.cstate.y = c_pose.pose.position.y		= d_state.y + current_cstate.y;
	target_state.cstate.z = c_pose.pose.position.z		= d_state.z + current_cstate.z;
	target_state.cstate.Rx = c_pose.pose.orientation.x	= d_state.Rx + current_cstate.Rx;
	target_state.cstate.Ry = c_pose.pose.orientation.y	= d_state.Ry + current_cstate.Ry;
	target_state.cstate.Rz = c_pose.pose.orientation.z	= d_state.Rz + current_cstate.Rz;
	target_state.cstate.w = c_pose.pose.orientation.w	= d_state.w + current_cstate.w;
	proxy.post_cartesian_pose(c_pose);
}


//bool IIWARobot::is_at_pose(double ebs) {
//	std::cout << "Error "<< (target_state_ - current_state_).norm() << std::endl;
//	return (target_state_ - current_state_).norm() < ebs;
//
//}

void IIWARobot::cartesian_compliace(double cx,double cy,double cz,double cRx,double cRy,double cRz) {
	iiwa_msgs::SmartServoMode config;
	config.mode = iiwa_msgs::SmartServoMode::CARTESIAN_IMPEDANCE;
	config.relative_velocity = 0.05;
	config.cartesian_stiffness.stiffness.x = cx;
	config.cartesian_stiffness.stiffness.y = cy;
	config.cartesian_stiffness.stiffness.z = cz;
	config.cartesian_stiffness.stiffness.a = cRx;
	config.cartesian_stiffness.stiffness.b = cRy;
	config.cartesian_stiffness.stiffness.c = cRz;

	config.cartesian_damping.damping.x = 0.7;
	config.cartesian_damping.damping.y = 0.7;
	config.cartesian_damping.damping.z = 0.7;
	config.cartesian_damping.damping.a = 0.7;
	config.cartesian_damping.damping.b = 0.7;
	config.cartesian_damping.damping.c = 0.7;
	proxy.post_configuration_smart_servo(config);
}

void IIWARobot::joint_compliace(double ca1, double ca2, double ca3, double ca4, double ca5, double ca6, double ca7) {
	iiwa_msgs::SmartServoMode config;
	config.mode = iiwa_msgs::SmartServoMode::JOINT_IMPEDANCE;
	config.relative_velocity = 0.05;
	config.joint_stiffness.stiffness.a1 = ca1;
	config.joint_stiffness.stiffness.a2 = ca2;
	config.joint_stiffness.stiffness.a3 = ca3;
	config.joint_stiffness.stiffness.a4 = ca4;
	config.joint_stiffness.stiffness.a5 = ca5;
	config.joint_stiffness.stiffness.a6 = ca6;
	config.joint_stiffness.stiffness.a7 = ca7;

	config.joint_damping.damping.a1 = 0.7;
	config.joint_damping.damping.a2 = 0.7;
	config.joint_damping.damping.a3 = 0.7;
	config.joint_damping.damping.a4 = 0.7;
	config.joint_damping.damping.a5 = 0.7;
	config.joint_damping.damping.a6 = 0.7;
	config.joint_damping.damping.a7 = 0.7;
	proxy.post_configuration_smart_servo(config);
}

double iiwaState::norm() {

	if(control == iiwaState::cartesian_space) {
		std::cout << "iiwaState::cartesian_space" << std::endl;
	}

	if(control == iiwaState::joint_space) {
		std::cout << "iiwaState::joint_space" << std::endl;
	}
	if(control == iiwaState::cartesian_space) {
		double sqrNorm =
				cstate.x * cstate.x +
				cstate.y * cstate.y +
				cstate.z * cstate.z;
		return sqrt(sqrNorm);
	} else if(control == iiwaState::joint_space) {
		double sqrNorm =
				qstate.q1 * qstate.q1 +
				qstate.q2 * qstate.q2 +
				qstate.q3 * qstate.q3 +
				qstate.q4 * qstate.q4 +
				qstate.q5 * qstate.q5 +
				qstate.q6 * qstate.q6 +
				qstate.q7 * qstate.q7;
		return sqrt(sqrNorm);
	}


	return 0;
}

iiwaState iiwaState::operator-(iiwaState st) {

	if(control == iiwaState::cartesian_space) {
		std::cout << "iiwaState::cartesian_space" << std::endl;
	}

	if(control == iiwaState::joint_space) {
		std::cout << "iiwaState::joint_space" << std::endl;
	}


	iiwaState diff_state;
	diff_state.control = control;
	if(control == iiwaState::cartesian_space) {
		diff_state.cstate.x = cstate.x - st.cstate.x;
		diff_state.cstate.y = cstate.y - st.cstate.y;
		diff_state.cstate.z = cstate.z - st.cstate.z;
		diff_state.cstate.Rx = cstate.Rx - st.cstate.Rx;
		diff_state.cstate.Ry = cstate.Ry - st.cstate.Ry;
		diff_state.cstate.Rz = cstate.Rz - st.cstate.Rz;
		diff_state.cstate.w = cstate.w - st.cstate.w;

	} else {
		diff_state.qstate.q1 = qstate.q1 - st.qstate.q1;
		diff_state.qstate.q2 = qstate.q2 - st.qstate.q2;
		diff_state.qstate.q3 = qstate.q3 - st.qstate.q3;
		diff_state.qstate.q4 = qstate.q4 - st.qstate.q4;
		diff_state.qstate.q5 = qstate.q5 - st.qstate.q5;
		diff_state.qstate.q6 = qstate.q6 - st.qstate.q6;
		diff_state.qstate.q7 = qstate.q7 - st.qstate.q7;
	}
	return diff_state;
}

}
