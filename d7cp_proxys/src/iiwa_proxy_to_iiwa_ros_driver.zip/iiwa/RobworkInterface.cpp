/*
 * RobworkInterface.cpp
 *
 *  Created on: Jan 24, 2017
 *      Author: josl
 */

#include <iiwa/RobworkInterface.h>
#include <rw/math/Quaternion.hpp>

namespace iiwa {

RobworkInterface::RobworkInterface(std::shared_ptr<RosProxy> ros_proxy) :
		proxy(ros_proxy)
{
}

RobworkInterface::~RobworkInterface()
{
}


rw::math::Q RobworkInterface::getQ()
{
	rw::math::Q q = toRw(proxy->get_msg_joint_position());
	return q;
}

rw::math::Transform3D<> RobworkInterface::getBaseTtool()
{
	rw::math::Transform3D<> baseTtool = toRw(proxy->get_msg_cartesian_pose());
	return baseTtool;
}


void RobworkInterface::movePtp(rw::math::Q q)
{
	iiwa_msgs::JointPosition msg = toRos(q);
	proxy->post_joint_position(msg);
	while(is_at(q) == false);
	ros::Duration(1).sleep();
}

void RobworkInterface::movePtp(std::vector<rw::math::Q> path, double eps)
{
	for(size_t i = 0; i < path.size(); i++)
	{
		iiwa_msgs::JointPosition msg = toRos(path[i]);
		proxy->post_joint_position(msg);
		while(is_at(path[i], eps) == false);
	}
	while(is_at(path.back()) == false);
	ros::Duration(1).sleep();
}


void RobworkInterface::moveLin(rw::math::Transform3D<> baseTtool)
{
	geometry_msgs::PoseStamped msg = toRos(baseTtool);
	proxy->post_cartesian_pose(msg);

}

void RobworkInterface::moveLin(double x, double y, double z, double rx, double ry, double rz)
{

}


void RobworkInterface::movePtpBlockExperimental(rw::math::Q q)
{
	rw::math::Q qCurrent = getQ();
	iiwa_msgs::JointPosition msg = toRos(q);
	proxy->post_joint_position(msg);

//	while(is_at_pose(q) == false);

	block_while_moving();
}

void RobworkInterface::movePtpBlockTimeout(rw::math::Q q, double timeout_sec)
{
	rw::math::Q qCurrent = getQ();
	iiwa_msgs::JointPosition msg = toRos(q);
	proxy->post_joint_position(msg);
	ros::Duration(timeout_sec).sleep();
}


bool RobworkInterface::is_moving()
{
	iiwa_msgs::JointPosition msgStart = proxy->get_msg_joint_position();
	rw::math::Q qStart = toRw(msgStart);

	ros::Duration(0.1).sleep();

	iiwa_msgs::JointPosition msgEnd = proxy->get_msg_joint_position();
	rw::math::Q qEnd = toRw(msgEnd);

	if((qEnd - qStart).norm2() > 1e-04)
		return true;
	return false;
}

void RobworkInterface::block_while_moving()
{
	iiwa_msgs::JointPosition msg1 = proxy->get_msg_joint_position();
	rw::math::Q q1 = toRw(msg1);
	ros::Time t1(msg1.header.stamp.sec, msg1.header.stamp.nsec);
//	std::cout << "BLOCKS" << std::endl;
	block_while_moving(q1, q1, t1);
//	std::cout << "RETURN" << std::endl;
}

void RobworkInterface::block_while_moving(rw::math::Q qInit, rw::math::Q qLast, ros::Time tStart)
{
	iiwa_msgs::JointPosition msg2 = proxy->get_msg_joint_position();
	rw::math::Q q2 = toRw(msg2);
	ros::Time t2(msg2.header.stamp.sec, msg2.header.stamp.nsec);

	double normLast = (q2 - qLast).norm2();
	double normInit = (q2 - qInit).norm2();
	ros::Duration duration = t2 -tStart;


	if(normLast == 0)
	{
		ros::Duration(0.01).sleep();
		block_while_moving(qInit, qLast, tStart);
		return;
	}

	if(normLast < 1e-04 && duration > ros::Duration(0.5))
		return;

	else if(normInit > 1e-03 && normLast < 1e-04)
		return;

	else
	{
//		std::cout << normInit << "  -  " << normLast << "  -  " << duration << std::endl;
		ros::Duration(0.01).sleep();
		block_while_moving(qInit, q2, tStart);
	}
}


bool RobworkInterface::is_at(rw::math::Q q, double eps)
{
	return (q - getQ()).norm2() < eps;
}

bool RobworkInterface::is_at(rw::math::Transform3D<> baseTtool_target, double eps)
{
	rw::math::Transform3D<> baseTtool_current = getBaseTtool();
	if(baseTtool_current.equal(baseTtool_target, eps))
		return true;
	return false;
}

void RobworkInterface::cartesian_compliace(double cx,double cy,double cz,double cRx,double cRy,double cRz)
{
	iiwa_msgs::SmartServoMode config;
	config.mode = iiwa_msgs::SmartServoMode::CARTESIAN_IMPEDANCE;
	config.relative_velocity = 0.05;
	config.cartesian_stiffness.stiffness.x = cx;
	config.cartesian_stiffness.stiffness.y = cy;
	config.cartesian_stiffness.stiffness.z = cz;
	config.cartesian_stiffness.stiffness.a = cRx;
	config.cartesian_stiffness.stiffness.b = cRy;
	config.cartesian_stiffness.stiffness.c = cRz;

	config.cartesian_damping.damping.x = 0.7;
	config.cartesian_damping.damping.y = 0.7;
	config.cartesian_damping.damping.z = 0.7;
	config.cartesian_damping.damping.a = 0.7;
	config.cartesian_damping.damping.b = 0.7;
	config.cartesian_damping.damping.c = 0.7;
	proxy->post_configuration_smart_servo(config);
}

void RobworkInterface::compliace_disable()
{
	iiwa_msgs::SmartServoMode config;
	config.mode = 2;
	proxy->post_configuration_smart_servo(config);
	ros::Duration(1).sleep();
}

rw::math::Transform3D<> RobworkInterface::toRw(geometry_msgs::PoseStamped msg)
{
	rw::math::Vector3D<> pos;
	pos[0] = msg.pose.position.x;
	pos[1] = msg.pose.position.y;
	pos[2] = msg.pose.position.z;
	rw::math::Quaternion<> rot;
	rot(0) = msg.pose.orientation.x;
	rot(1) = msg.pose.orientation.y;
	rot(2) = msg.pose.orientation.z;
	rot(3) = msg.pose.orientation.w;
	rw::math::Transform3D<> transform(pos, rot.toRotation3D());
	return transform;
}

geometry_msgs::PoseStamped RobworkInterface::toRos(rw::math::Transform3D<> baseTtool)
{
	geometry_msgs::PoseStamped msg;
	rw::math::Vector3D<> p(baseTtool.P());
	rw::math::Quaternion<> q(baseTtool.R());
	return toRos(p[0], p[1], p[2], q.getQx(), q.getQy(), q.getQz(), q.getQw());
}

geometry_msgs::PoseStamped RobworkInterface::toRos(double x, double y, double z, double qx, double qy, double qz, double qw)
{
	geometry_msgs::PoseStamped msg;
	msg.pose.position.x = x;
	msg.pose.position.y = y;
	msg.pose.position.z = z;
	msg.pose.orientation.x = qx;
	msg.pose.orientation.y = qy;
	msg.pose.orientation.z = qz;
	msg.pose.orientation.w = qw;
	return msg;
}

rw::math::Q RobworkInterface::toRw(iiwa_msgs::JointPosition msg)
{
	rw::math::Q q(7);
	q[0] = msg.position.a1;
	q[1] = msg.position.a2;
	q[2] = msg.position.a3;
	q[3] = msg.position.a4;
	q[4] = msg.position.a5;
	q[5] = msg.position.a6;
	q[6] = msg.position.a7;
	return q;
}

iiwa_msgs::JointPosition RobworkInterface::toRos(rw::math::Q q)
{
	iiwa_msgs::JointPosition msg;
	msg.position.a1 = q[0];
	msg.position.a2 = q[1];
	msg.position.a3 = q[2];
	msg.position.a4 = q[3];
	msg.position.a5 = q[4];
	msg.position.a6 = q[5];
	msg.position.a7 = q[6];
	return msg;
}




} /* namespace iiwa */
