/*
 * iiwa_interface.h
 *
 *  Created on: Nov 30, 2016
 *      Author: jpb
 */

#ifndef CARMEN_IIWA_INCLUDE_CARMEN_IIWA_INTERFACES_IIWA_ROBOT_H_
#define CARMEN_IIWA_INCLUDE_CARMEN_IIWA_INTERFACES_IIWA_ROBOT_H_

#include "RosProxy.h"

namespace iiwa {

struct Qstate {
	Qstate(){q1=q2=q3=q4=q5=q6=q7=0;}
	float q1, q2, q3, q4, q5, q6, q7;
};

struct Cstate {
	Cstate() {x = y = z = Rx = Ry = Rz = w = 10000;}
	Cstate(double x,double y,double z,double Rx,double Ry,double Rz, double w) : x(x),y(y),z(z),Rx(Rx),Ry(Ry),Rz(Rz), w(w) {}
	double x, y, z, Rx, Ry, Rz ,w;
};

struct iiwaState {
	Qstate qstate;
	Cstate cstate;
	enum Control{cartesian_space,joint_space};
	Control control;
	double norm();
	iiwaState operator-(iiwaState st);
};

class IIWARobot {
public:
	 IIWARobot(RosProxy & rosproxy);
	 virtual ~IIWARobot();

	 iiwaState getState();
	 Qstate getQ();

 	 void moveQ(const Qstate & state);
	 void move_dQ(const Qstate & d_state);

	 void moveC(const Cstate & state);
	 void move_dc(const Cstate & d_state);

//	 bool is_at_pose(double ebs = 0.01);

	 void cartesian_compliace(double cx,double cy,double cz,double cRx,double cRy,double cRz);
	 void joint_compliace(double ca1, double ca2, double ca3, double ca4, double ca5, double ca6, double ca7);

private:
	 RosProxy & proxy;

};

}
#endif /* CARMEN_IIWA_INCLUDE_CARMEN_IIWA_INTERFACES_IIWA_ROBOT_H_ */
